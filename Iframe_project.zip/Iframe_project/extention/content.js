(() => {
    let iframe = document.querySelector("iframe");

    if (iframe) {
        try {
            let iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            let text = iframeDoc.body.innerText;

            navigator.clipboard.writeText(text).then(() => {
                alert("Iframe content copied!");
                console.log("Iframe content copied successfully!");
            }).catch(err => console.error("Copy failed", err));
        } catch (e) {
            alert("Cannot access iframe content (Possible cross-origin issue)");
            console.error("Error:", e);
        }
    } else {
        alert("No iframe found on this page!");
    }
})();
